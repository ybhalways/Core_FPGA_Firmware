#ifndef _CONFIG_H_
#define _CONFIG_H_

/**************************
  Congfig mod num frq
***************************/

//#define _Config_mod_ 0
//#define _Config_num_ 1
//#define _Config_frq_ 24


/**************************
  Function selection
***************************/
#define ENABLE_BEEP
#define ENABLE_LED
#define ENABLE_SHOOTER
#define ENABLE_HEARTBEAT
#define ENABLE_POWERMON
#define ENABLE_SHOOT_COUNT
#define ENABLE_2401_RESTART


/***************************
  System Configuration
***************************/
#define CHANNEL_NUM 4
#define ERROR_NUM 1000
#define SHOOTER_NUM 2


/***************************
  Electrical & Mechanical 
      Configuration
***************************/
#define MOTOR_KP  210
#define MOTOR_KI  150

#define MAX_SHOT_STRENGTH 150
#define MAX_ACC max_acc()//�޶����ӵļ��ٶ�

#define WHEEL_CENTER_OFFSET 0.082  /* ���Ӿ೵���ľ���(m) */
#define D_WHEEL_ANGLE_FRONT 58//58//55���ϳ���//60/* ǰ�������߽Ƕ�(��) */
#define D_WHEEL_ANGLE_BACK 135//135//128���ϳ���//125 //134 /* ���������߽Ƕ�(��) */
#define D_WHEEL_REDUCTION_RATIO_X 3//3; /*���ٱ�*/     // X.YZ
#define D_WHEEL_REDUCTION_RATIO_YZ 18//28; /*���ٱ�*/   //X.YZ

#define ENCODER_COUNTS_PER_TURN_SET 360
#define WHEEL_RADIUS 0.028

#define SHOOT_DELAY 15


/***************************
  Circuit Configuration
***************************/

#define WARNING_POWER_A 15.4
#define FORCESTOP_POWER_A 14.8

#define WARNING_POWER_D (13.51*WARNING_POWER_A-3.951)  
#define FORCESTOP_POWER_D (13.51*FORCESTOP_POWER_A-1.951) 

#define D_MAX_DRIBBLER  125
#define V_MAX_DRIBBLER  100

#define DO_PID_FRQ 500

#define CLKFREQ    50000000UL
#define TICKFREQ    1000 // ��ʱ��Ƶ��
#define INFRA_FREQ 38000
#define INFRA_DUTY 0.2

#define SHOOTER_INTERVAL 1000// �������ż��ʱ��

#define NRF2401_ADDR_COUNT    5

#define NRF2401_ADDR1_4     0x10
#define NRF2401_ADDR1_3     0x71
#define NRF2401_ADDR1_2     0x45
#define NRF2401_ADDR1_1     0x98
#define NRF2401_ADDR1_0     0x00

#define NRF2401_CAR_4     0x00
#define NRF2401_CAR_3     0x10
#define NRF2401_CAR_2     0x13
#define NRF2401_CAR_1     0x21
#define NRF2401_CAR_0     0x88

#define PACKET_LEN    25   //This Packet_len must accord with Transfer's Packet_len 
#define PACKET_LEN_UP 25	//2401����ͨѶ�ֽ���//

#define LOWPOWERTIME 30
#define CAP_POWER_LOW 20 //15V

#define STR_9557_SET 0;
#define STEP_9557_SET 4;


#endif

