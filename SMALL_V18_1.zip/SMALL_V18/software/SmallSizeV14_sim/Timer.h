#ifndef _TIMER_H_
#define _TIMER_H_

#include <io.h>
#include "system.h"
#include "Config.h"

void do_timer( void * context, alt_u32 id);

#endif
