/*******************************************************************************
*                                                                              
* System Library Project  													   
* ======================                                                       
*                                                                              
* 	This is the library project custom created for your hardware system.       
* 	It is built up from auto-generated files and component source files.       
*                                                                              
*  	The auto-generated system source files can be found in:	                    
* 		<configuration_folder>/system_description  	                           
*  		e.g. Release/system_description/system.h		                         			                                                                        *
* 																			   	
*  	The component source files from the relevant sopc component folders        
* 		e.g. <sopc_kit_nios2>/components/altera_nios2                          
* 																			   	
* 	To change the system library build properties, right click on the project  
* 		and select properties. This allows you to set options like timers,     
* 		memory sections and build options.                                     
*                                                                                                                                                            *
*******************************************************************************/
